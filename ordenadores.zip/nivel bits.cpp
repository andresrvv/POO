//Andres Ruiz Velasco - Braulio Lopez
//Operadores a nivel de bits
//https://www.youtube.com/watch?v=ykowfOF3gWw


#include <iostream>
using namespace std;
int main() {
  int cont = 128; //numero de 0 que se ocuparan =00000000
  int cont2 =128;
  int cont3 = 128;
  char numero = 5;   //00000101
  char numero2 = 4; // 00000100

  cout << "--AND--" <<endl;
  char opand =  numero & numero2; // operador and
  cout << "El resultado es: " ; 
   printf("%i \n", opand);
  for(cont; cont > 0; cont >>=1){
    if(cont & opand){
      printf("1");
    } else{
      printf("0");
    }
  }
  cout << endl;
  cout<< "--OR exclusivo--" ;
  char oporex = numero ^ numero2; // operador or exclusivo
  cout << endl << "El resultado es: " ; 
   printf("%i \n", oporex);
  for(cont2; cont2 > 0; cont2 >>=1){
    if(cont2 & oporex){
      printf("1");
    } else{
      printf("0");
    }
  }
  cout << endl;
  cout << "--OR inclusivo--";
  char oporin = numero | numero2; // operador or inclusivo
  cout << endl << "El resultado es: " ; 
   printf("%i \n", oporin);
 for(cont3; cont3 > 0; cont3 >>=1){
    if(cont3 & oporin){
      printf("1");
    } else{
      printf("0");
    }
  }
  
  
}